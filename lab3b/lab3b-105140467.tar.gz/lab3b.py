#!/usr/bin/env python3
# NAME: Megan Pham, Cody Do
# EMAIL: megspham@ucla.edu, D.Codyx@gmail.com
# ID: 505313300, 105140467

import csv
import sys

##########################
###  GLOBAL VARIABLES  ###
##########################

inodes=dict()
allBlocks = dict() 
freeList = set() 
inodebitmap=[]
blockbitmap=[]
group = None
sb= None
dirents=[]
errors = 0

#################
###  CLASSES  ###
#################

class blockData():
    def __init__(self, blocknum, inum, offset, level):
        self.blocknum = blocknum
        self.inum = inum
        self.offset = offset
        self.level = level
        
class inode():
    def __init__(self, frow):
        self.inum = int(frow[1])
        self.group = int(frow[5])
        self.link = int(frow[6])
        
class superblock():
    def __init__(self, frow):
        self.blocknum = int(frow[1])
        self.inodenum = int(frow[2])
        self.blocksz = int(frow[3])
        self.inodesz = int(frow[4])
        self.blockpg = int(frow[5])
        self.inodespg = int(frow[6])
        self.nonreserved = int(frow[7])

class Group():
    def __init__(self, frow):
        self.blocknum = int(frow[2])  
        self.inodenum = int(frow[3])
        self.freeblocks = int(frow[4])
        self.freeinodes = int(frow[5])
        self.blockbitmap = int(frow[6])
        self.inodebitmap = int(frow[7])
        self.inodesblock = int(frow[8])

class directory():
    def __init__(self, frow):
        self.pnum = int(frow[1])
        self.inum = int(frow[3])
        self.name = frow[6]

###################
###  FUNCTIONS  ###
###################

def handleInodeAudit(sb, inodeMap):
    for i in inodes:
        freeList.add(i) 
    for i in range(sb.nonreserved, sb.inodenum):
        if i not in freeList and i not in inodeMap:
            print("UNALLOCATED INODE " + str(i)+ " NOT ON FREELIST")
    for i in freeList:
        if i in inodeMap:
            print("ALLOCATED INODE " +str(i)+ " ON FREELIST")

def handleBlockAudit(sb, group):
    global errors
    start = int(group.inodesblock + (sb.inodesz * group.inodenum)/sb.blocksz)
    highestblock = sb.blocknum
    
    #check for unreferenced blocks - not referenced to any blocks and is not in free list
    for i in range(start, highestblock):
        if i not in blockbitmap and i not in allBlocks:
            print("UNREFERENCED BLOCK " + str(i))
            errors +=1
            
    for j in allBlocks:
        temp = list(allBlocks[j])
        bl = temp[0]
        
        if bl.level == 1:
            label = " INDIRECT "
        elif bl.level == 2:
            label = " DOUBLE INDIRECT "
        elif bl.level == 3:
            label = " TRIPLE INDIRECT "
        else:
            label = " "
            
        #invalid is less than zero or greater than highest block
        if j < 0 or j >= highestblock:
            errors +=1
            print("INVALID" + str(label)+ "BLOCK " + str(bl.blocknum) +
            " IN INODE " + str(bl.inum) + " AT OFFSET " + str(bl.offset))
        elif bl.blocknum in blockbitmap: #block that is allocated to some file and appears on free list
            errors +=1
            print ("ALLOCATED BLOCK " + str(bl.blocknum) + " ON FREELIST")
        #reserved cannot be allocated to any file 
        elif j < start:
            errors +=1
            print("RESERVED" + str(label)+ "BLOCK " + str(bl.blocknum) +
            " IN INODE " + str(bl.inum) + " AT OFFSET " + str(bl.offset))

        #check for duplicate references
        elif len(temp) > 1:
            for d in temp:
                errors +=1
                if d.level == 1:
                    print("DUPLICATE INDIRECT BLOCK "+ str(d.blocknum)+ " IN INODE " +str(d.inum) + " AT OFFSET " + str(d.offset))
                elif d.level == 2:
                    print("DUPLICATE DOUBLE INDIRECT BLOCK "+ str(d.blocknum)+ " IN INODE " +str(d.inum) + " AT OFFSET " + str(d.offset))
                elif d.level == 3:
                    print("DUPLICATE TRIPLE INDIRECT BLOCK "+ str(d.blocknum)+ " IN INODE " +str(d.inum) + " AT OFFSET " + str(d.offset))
                else:
                    print("DUPLICATE BLOCK "+ str(d.blocknum)+ " IN INODE " +str(d.inum) + " AT OFFSET " + str(d.offset))


def handleDirectoryAudit(inodeList, sb, directory, inodeMap):
    # numLinks = link count of inodes existing in directories 
    numLinks = [0] * sb.inodenum
    parents = [0] * sb.inodenum
    parents[2] = 2 
    global errors

    # Scan content and check if inode number is valid. If not, output
    # the proper message
    for d in directory:
        # d is not allocated and exists in the the inode bitmap as free
        if d.inum not in freeList and d.inum in inodeMap: #not allocated and in the inode bitmap as free
            print("DIRECTORY INODE " + str(d.pnum) + " NAME " + str(d.name) + " UNALLOCATED INODE " + str(d.inum))
            errors += 1
        elif d.inum > sb.inodenum or d.inum <1:
            print("DIRECTORY INODE " + str(d.pnum) + " NAME " + str(d.name) + " INVALID INODE " + str(d.inum))
            errors += 1
        else:
            # enumerate the link
            numLinks[d.inum] += 1 

    # Scan content and save pointer to parent
    for d in directory:
            if d.name != "'.'" and d.name != "'..'" and d.inum < len(parents):
                parents[d.inum] = d.pnum

    # Scan inodes and check for mismatching link counts
    for inode in inodeList.values():
        if inode.link != numLinks[inode.inum]:
            print("INODE " + str(inode.inum) + " HAS " + str(numLinks[inode.inum]) + " LINKS BUT LINKCOUNT IS " + str(inode.link))
            errors += 1
    
    # Scan to check for inconsistencies of . and ..
    for  d in directory:
        if d.name == "'.'" and d.inum !=d.pnum:
            print("DIRECTORY INODE " + str(d.pnum) + " NAME '.' LINK TO INODE " + str(d.inum) + " SHOULD BE " + str(d.pnum))
            errors += 1
        elif d.name =="'..'" and d.inum != parents[d.inum]:
            print("DIRECTORY INODE " + str(d.pnum) + " NAME '..' LINK TO INODE " + str(d.inum) + " SHOULD BE " + str(parents[d.inum]))
            errors += 1

def main():
    # Check number of arguments
    if len(sys.argv) < 2:
        sys.stderr.write("incorrect number of arguments\n")
        sys.exit(1)

    # Attempt to open csv file
    try:
        inputCSV = open(sys.argv[1], 'r')
    except IOError:
        sys.stderr.write("cannot open csv file\n")
        sys.exit(1)

    readCSV = csv.reader(inputCSV)

    # Loop through each row in the read csv file
    for row in readCSV:
        tag = row[0]
        if tag == 'SUPERBLOCK':
            sb = superblock(row)
        elif tag == 'GROUP':
            group = Group(row)
        elif tag == 'INODE':
            # Create a single inode and place into dictionary of inodes
            # Key: inode number, Value: inode itself
            singleInode = inode(row)
            inodes[int(row[1])] = singleInode

            for i in range(15):
                address = int(row[12+i])

                # Create newBlock in first 12 of 15
                if i >= 12 and address > 0:
                    level = i - 11
                    offset = i

                    if level == 1:
                        offset = 12
                    elif level == 2:
                        offset = 268
                    elif level == 3:
                        offset = 65804

                    newBlock = blockData(address, int(row[1]), offset, level)

                # Create newBlcok in last 3 of 15
                elif address > 0:
                    newBlock = blockData(address, int(row[1]), i, 0 )

                # React accordingly with the created newBlock (from above)
                if address > 0:
                    if address not in allBlocks:
                        allBlocks[address] = set()
                    allBlocks[address].add(newBlock)
        
        elif tag == 'BFREE':
            blockbitmap.append(int(row[1]))
        elif tag == 'IFREE':
            inodebitmap.append(int(row[1]))
        elif tag =='DIRENT':
            dirents.append(directory(row))
        elif tag =='INDIRECT':
            newBlock = blockData(int(row[5]), int(row[1]), int(row[3]),int(row[2]) - 1 )
            if int(row[5]) not in allBlocks:
                allBlocks[int(row[5])] = set()
            allBlocks[int(row[5])].add(newBlock)
    
    
    handleInodeAudit(sb,inodebitmap)         
    handleBlockAudit(sb,group)
    handleDirectoryAudit(inodes,sb, dirents,inodebitmap)

    if errors == 0:
        sys.exit(0)
    else:
        sys.exit(2)


if __name__ =='__main__':
    main()

